package com.employee.demo.models;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name="myseq", initialValue= 1000)
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "myseq")
	Integer employeeId;
	String firstName;
	String lastName;
	Double salary;
	LocalDate dateOfJoining;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="dept_fk")
	Department dept;
	
	@OneToMany(mappedBy="employee", cascade = CascadeType.ALL)
	List<Address> addressDtls;
	
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	public List<Address> getAddressDtls() {
		return addressDtls;
	}
	public void setAddressDtls(List<Address> addressDtls) {
		this.addressDtls = addressDtls;
	}
}
