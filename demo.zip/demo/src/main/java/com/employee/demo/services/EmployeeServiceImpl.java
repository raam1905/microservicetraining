package com.employee.demo.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.employee.demo.models.Address;
import com.employee.demo.models.Employee;
import com.employee.demo.repositories.AddressRepository;
import com.employee.demo.repositories.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepository empRepo;
	
	@Autowired
	AddressRepository addressRepo;
	
	
	/* (non-Javadoc)
	 * @see com.employee.demo.services.EmployeeService#getEmployeeById(java.lang.Integer)
	 */
	@Override
	public Employee getEmployeeById(Integer id) {
		Optional<Employee> employee = empRepo.findById(id);
		if(employee.isPresent())
			return employee.get();
		else
			return null;
	}
	
	
	/* (non-Javadoc)
	 * @see com.employee.demo.services.EmployeeService#addEmployee(com.employee.demo.models.Employee)
	 */
	@Override
	public Employee addEmployee(Employee emp) {
		List<Address> addressList = emp.getAddressDtls().parallelStream().map((e)->{e.setEmployee(emp);
														return e;}).collect(Collectors.toList());
		emp.setAddressDtls(addressList);
		Employee employee = empRepo.save(emp);
		return employee;
	}
	
	/* (non-Javadoc)
	 * @see com.employee.demo.services.EmployeeService#deleteEmployee(java.lang.Integer)
	 */
	@Override
	public void deleteEmployee(Integer id) {
		Optional<Employee> employee = empRepo.findById(id);
		if(employee.isPresent()) {
			Employee e = employee.get();
			
			empRepo.delete(e);
		}
		
	}
	
	
	/* (non-Javadoc)
	 * @see com.employee.demo.services.EmployeeService#updateEmployee(com.employee.demo.models.Employee)
	 */
	@Override
	public Employee updateEmployee(Employee emp) {
		Optional<Employee> employee = empRepo.findById(emp.getEmployeeId());
		if(employee.isPresent()) {
			Employee e = employee.get();
			emp.getAddressDtls().stream().forEach((address)->{
					
					
					address.setEmployee(e);
					addressRepo.save(address);
				}); 
			e.setAddressDtls(emp.getAddressDtls());
			e.setFirstName(emp.getFirstName());
			e.setLastName(emp.getLastName());
			e.setSalary(emp.getSalary());
			e.setDept(emp.getDept());
			e.setDateOfJoining(emp.getDateOfJoining());
			empRepo.save(e);
			return  empRepo.findById(emp.getEmployeeId()).get();
		}
		else
			return null;
			
		
	}
	public Employee patchEmployeeData(Employee emp) {
		
		Optional<Employee> employee = empRepo.findById(emp.getEmployeeId());
		
		if(employee.isPresent()) {
			Employee e = employee.get();
			if(emp.getAddressDtls()!=null) {
				emp.getAddressDtls().stream().forEach((address)->{
					
					
						address.setEmployee(e);
						addressRepo.save(address);
					});
				e.setAddressDtls(emp.getAddressDtls());
			}
			
			if(emp.getDept()!=null)
				e.setDept(emp.getDept());
			
			if(!StringUtils.isEmpty(emp.getFirstName()))
					e.setFirstName(emp.getFirstName());
			
			if(!StringUtils.isEmpty(emp.getLastName()))
					e.setLastName(emp.getLastName());
			
			if(!StringUtils.isEmpty(emp.getSalary()))
					e.setSalary(emp.getSalary());
			

			
			if(!StringUtils.isEmpty(emp.getDateOfJoining()))
				e.setDateOfJoining(emp.getDateOfJoining());
			
			empRepo.save(e);
			return e;
		}
		else
			return null;
			
		
	}
}
