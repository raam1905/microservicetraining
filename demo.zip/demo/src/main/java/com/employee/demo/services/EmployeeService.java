package com.employee.demo.services;

import com.employee.demo.models.Employee;

public interface EmployeeService {

	Employee getEmployeeById(Integer id);

	Employee addEmployee(Employee emp);

	void deleteEmployee(Integer id);

	Employee updateEmployee(Employee emp);
	Employee patchEmployeeData(Employee emp);

}