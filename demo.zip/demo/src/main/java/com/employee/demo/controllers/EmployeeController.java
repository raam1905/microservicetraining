package com.employee.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.demo.models.Employee;
import com.employee.demo.services.EmployeeService;

@RestController
@RequestMapping("/api/v1/employee")
public class EmployeeController {
	@Autowired
	EmployeeService empService;
	@GetMapping("/")
	public String sayHello() {
		return "Hello";
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Employee> getEmployeeDetails(@PathVariable("id") Integer empId){
		Employee e = empService.getEmployeeById(empId);
		if(e!=null)
			return new ResponseEntity<Employee>(e,HttpStatus.OK);
		else
			return new ResponseEntity<Employee>(HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/")
	public ResponseEntity<Employee> addEmployeeDetails(@RequestBody Employee e){
		Employee emp = empService.addEmployee(e);
		if(emp!=null)
			return new ResponseEntity<Employee>(emp,HttpStatus.CREATED);
		else
			return new ResponseEntity<Employee>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	@PutMapping("/{id}")
	public ResponseEntity<Employee> updateEmployeeDetails( @RequestBody Employee e , @PathVariable("id") Integer empId){
		e.setEmployeeId(empId);
		Employee emp = empService.updateEmployee(e);
		if(emp!=null)
			return new ResponseEntity<Employee>(emp,HttpStatus.OK);
		else
			return new ResponseEntity<Employee>(HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Employee> deleteEmployeeDetails( @PathVariable("id") Integer empId){
		empService.deleteEmployee(empId);
		return new ResponseEntity<Employee>(HttpStatus.NO_CONTENT);
		
	}
	
	@PatchMapping("/{id}")
	public ResponseEntity<Employee> updatePartialEmployeeData( @RequestBody Employee e , @PathVariable("id") Integer empId){
		e.setEmployeeId(empId);
		Employee emp = empService.patchEmployeeData(e);
		if(emp!=null)
			return new ResponseEntity<Employee>(emp,HttpStatus.OK);
		else
			return new ResponseEntity<Employee>(HttpStatus.INTERNAL_SERVER_ERROR);
		
		
	}
	
}
